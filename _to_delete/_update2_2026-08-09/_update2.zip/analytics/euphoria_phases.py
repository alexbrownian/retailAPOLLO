"""
euphoria_phases.py
==================
Ground truth + feature bank for the euphoria PHASES study (July 2026):
detect not just the END of retail euphoria (the existing top detector in
analytics/euphoria.py) but also its START - the onset of a GME-scale
rally - from the crowd alone.

WHAT THIS MODULE OWNS
---------------------
1. EPISODES - the price-defined ground truth. An episode is the full
   boom-bust arc trough -> peak -> bust, built from the SAME peak
   definition the top detector is scored on (G1-G3 in euphoria.py), so
   the two detectors share one notion of "a genuine euphoria event".
2. The ONSET FEATURE BANK - six trailing, crowd-only candidate features
   aimed at the LEFT side of an episode (the crowd arriving), evaluated
   in notebook 02 with the full feature-importance battery.
3. The LABELLED DAY FRAME - one row per (instrument, candidate day) with
   features + onset/top labels, shared by notebooks 02 and 03 and by the
   production detector, so research and dashboard can never drift apart.

DESK DECISIONS (July 2026, recorded before any result was computed)
-------------------------------------------------------------------
* ONSET HIT WINDOW: an onset alert is a HIT when it lands inside
  [trough, min(trough + 45d, peak)]. The trough is the 120d low the boom
  is measured from (G2), so "the start" is anchored to the same low the
  peak definition already uses - no new fitted quantity. The window is
  CAPPED AT THE PEAK: for fast rallies an uncapped +45d would let an
  alert fired AFTER the top count as "caught the start".
* LATE is not FALSE: an onset alert inside (window end, peak] fired
  during the rally but after its start. It is reported as LATE -
  separately from hits AND from false alarms - because calling it a hit
  inflates the onset claim and calling it false punishes an alert that
  was inside a genuine episode. Only alerts outside the whole episode
  count as false alarms.
* CROWD-ONLY PREDICTION (unchanged hard rule): price never enters any
  feature or alert below - price appears ONLY here, in the ground-truth
  episode definition and the scoring.

All feature rules are trailing (day t uses only data <= t) and are
percentile ranks against the SAME instrument's own trailing history, for
the same reasons as E1-E5 (fat tails -> ranks, coverage shifts -> shares).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from src.config import (EUPHORIA_CRASH_MIN_ETF, EUPHORIA_CRASH_MIN_SINGLE,
                        EUPHORIA_MIN_HISTORY,
                        EUPHORIA_FA_BUDGET_PER_IY)
from analytics.euphoria import (EuphoriaSeries, ground_truth_peaks,
                                judgeable_window, trailing_pct_rank,
                                log_convexity, _mention_share,
                                _bullish_series)
from analytics.loaders import load, TICKER_COUNTS_BY_SOURCE

# Desk decision (July 2026): the onset hit window length. Anchored to the
# trough that G2 already defines, capped at the peak (see module docstring).
ONSET_WINDOW_DAYS = 45

# The window in which a peak "answers" a TOP alert - identical to the
# stated aim in euphoria.py ([peak-30d, peak+1d]), repeated here so the
# labelled frame can be built without re-deriving it.
TOP_LEAD_DAYS = 30


# ---------------------------------------------------------------------------
# 1. EPISODES - the price-defined ground truth (trough -> peak -> bust)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Episode:
    """One complete boom-bust arc for one instrument. Frozen: ground
    truth is evidence, never something downstream code may edit."""
    name: str                      # theme name or ticker
    symbol: str                    # priced symbol behind it
    kind: str                      # "theme" | "single"
    trough: pd.Timestamp           # t_start: the 120d low the boom grew from
    peak: pd.Timestamp             # the confirmed top (G1-G3)
    bust_date: pd.Timestamp | None  # first close down >= crash_min from peak
    boom_pct: float                # trough -> peak gain (e.g. 0.5 = +50%)
    bust_pct: float                # peak -> 90d-min drawdown (negative)
    run_days: int                  # trough -> peak, calendar days
    onset_lo: pd.Timestamp         # = trough
    onset_hi: pd.Timestamp         # = min(trough + ONSET_WINDOW_DAYS, peak)


def find_episodes(px: pd.Series, name: str, symbol: str,
                  kind: str, boom_min: float | None = None,
                  crash_min: float | None = None) -> list[Episode]:
    """Extend each confirmed peak (the existing G1-G3 definition) into a
    full episode by walking BACKWARD to its trough and FORWARD to its
    bust. Nothing here is new ground truth - the trough is exactly the
    'min close over the preceding 120d' that G2 already measures the
    boom against, and the bust date is the first day G3's drawdown
    condition is met. boom_min/crash_min: sweep overrides, config
    defaults when None (see ground_truth_peaks)."""
    if crash_min is None:
        crash_min = (EUPHORIA_CRASH_MIN_SINGLE if kind == "single"
                     else EUPHORIA_CRASH_MIN_ETF)
    px = px.dropna()
    episodes = []
    for peak in ground_truth_peaks(px, kind, boom_min=boom_min,
                                   crash_min=crash_min):
        prior = px.loc[peak - pd.Timedelta(days=120):peak]
        trough = prior.idxmin()
        peak_close = px.loc[peak]
        after = px.loc[peak:peak + pd.Timedelta(days=90)]
        drawdown = after / peak_close - 1.0
        busted = drawdown[drawdown <= -crash_min]
        episodes.append(Episode(
            name=name, symbol=symbol, kind=kind,
            trough=trough, peak=peak,
            bust_date=busted.index[0] if len(busted) else None,
            boom_pct=float(peak_close / prior.min() - 1.0),
            bust_pct=float(drawdown.min()),
            run_days=int((peak - trough).days),
            onset_lo=trough,
            onset_hi=min(trough + pd.Timedelta(days=ONSET_WINDOW_DAYS), peak),
        ))
    return episodes


def episode_catalog(series: list, pxmap: dict,
                    gt_override: dict | None = None) -> pd.DataFrame:
    """Every episode for every instrument, as one flat table, with the
    two detectability flags the report always shows side by side:

    onset_detectable : the coverage gate (A0) held on >= 1 day of the
                       onset window - a start no crowd was measurable
                       for stays in the "all" denominator but cannot
                       honestly score a crowd detector;
    top_detectable   : same flag over [peak-30d, peak] (the existing
                       definition in euphoria.peak_maps)."""
    gt = gt_override or {}
    rows = []
    for es in series:
        for ep in find_episodes(
                pxmap[es.symbol], es.name, es.symbol, es.kind,
                boom_min=gt.get(f"boom_{es.kind}"),
                crash_min=gt.get(f"crash_{es.kind}")):
            onset_cov = es.coverage_ok.loc[ep.onset_lo:ep.onset_hi]
            top_cov = es.coverage_ok.loc[ep.peak - pd.Timedelta(days=30):ep.peak]
            rows.append({
                "name": ep.name, "symbol": ep.symbol, "kind": ep.kind,
                "trough": ep.trough, "peak": ep.peak,
                "bust_date": ep.bust_date,
                "boom_pct": ep.boom_pct, "bust_pct": ep.bust_pct,
                "run_days": ep.run_days,
                "onset_lo": ep.onset_lo, "onset_hi": ep.onset_hi,
                "year": int(ep.peak.year),
                "onset_detectable": bool(len(onset_cov) and onset_cov.any()),
                "top_detectable": bool(len(top_cov) and top_cov.any()),
            })
    cols = ["name", "symbol", "kind", "trough", "peak", "bust_date",
            "boom_pct", "bust_pct", "run_days", "onset_lo", "onset_hi",
            "year", "onset_detectable", "top_detectable"]
    return (pd.DataFrame(rows, columns=cols)
            .sort_values(["peak", "name"]).reset_index(drop=True))


# ---------------------------------------------------------------------------
# 2. THE ONSET FEATURE BANK - six crowd-only candidates for "the start"
# ---------------------------------------------------------------------------
# Names + one-line definitions (all trailing pct-ranks vs own history):
#   O1 attention_accel   7d mention share minus 28d share - the crowd is
#                        arriving faster than its own monthly norm
#   O2 hype_ratio        7d share / own trailing 120d median share - the
#                        continuous version of the A1 hype gate
#   O3 bull_inflection   14d change of the 14d net-bullish share - the
#                        mood is TURNING up (vs E2's "has been up")
#   O4 influx_speed      14d change of the mention share - E3's crowd
#                        influx measured at twice the speed
#   O5 attention_convexity  E5's super-exponential growth signature -
#                        inherently an EARLY-phase feature (contagion)
#   O6 source_breadth    how many of the 4 sources mentioned the name in
#                        the last 7d - a real crowd spreads across
#                        platforms, a single loud thread does not
ONSET_FEATURES = ["attention_accel", "hype_ratio", "bull_inflection",
                  "influx_speed", "attention_convexity", "source_breadth"]

# The LOCKED production bank (notebook 02's verdict): source_breadth is
# EXCLUDED - its apparent skill was a coverage-regime artifact (X and
# StockTwits exist in the archive only from 2026, so "breadth" mostly
# encoded "which year is it"). Notebooks 03/04 and the live detector all
# import THIS list - research and production cannot drift.
ONSET_BANK = ["attention_accel", "hype_ratio", "bull_inflection",
              "influx_speed", "attention_convexity"]

# The incumbent bank, for side-by-side evaluation in the notebooks.
TOP_FEATURES = ["e1", "e2", "e3", "e5", "fade"]


def _source_breadth(name: str, all_days: pd.DatetimeIndex) -> pd.Series | None:
    """O6: count of distinct sources mentioning the name in the trailing
    7d. Only tickers have a by-source aggregate; for themes this returns
    None and the feature is simply absent (the frame builder drops it)."""
    by_src = load(TICKER_COUNTS_BY_SOURCE)
    if by_src is None or "source" not in by_src.columns:
        return None
    one = by_src[by_src["ticker"] == name]
    if one.empty:
        return None
    one = one.assign(date=pd.to_datetime(one["date"]))
    daily = (one.groupby(["date", "source"])["mention_count"].sum()
             .unstack(fill_value=0).reindex(all_days).fillna(0.0))
    return (daily.rolling(7, min_periods=1).sum() > 0).sum(axis=1).astype(float)


def compute_onset_features(name: str, counts_long: pd.DataFrame,
                           sent_long: pd.DataFrame, entity_col: str,
                           with_breadth: bool = True,
                           by_source: pd.DataFrame | None = None
                           ) -> pd.DataFrame:
    """The onset feature bank for one instrument - crowd aggregates ONLY
    (no price argument exists, by design; enforced by a unit test).
    Returns a daily DataFrame with one column per available feature."""
    all_days = pd.date_range(counts_long["date"].min(),
                             counts_long["date"].max(), freq="D")
    share, m7 = _mention_share(counts_long, entity_col, name, all_days,
                               by_source=by_source)

    # O1: is this week's crowd bigger than this month's? (both in share
    # space, so a platform-wide busy day cancels out)
    share28 = share.rolling(28, min_periods=7).mean()
    o1 = trailing_pct_rank(share - share28)

    # O2: the hype gate's ratio as a continuous feature - how many times
    # its own 120d median the current 7d share is
    base = share.rolling(120, min_periods=60).median()
    o2 = trailing_pct_rank(share / base.where(base > 0))

    # O3: the mood turning up - 14d change of the 14d net-bullish share
    one = sent_long[sent_long[entity_col] == name]
    n = one.groupby("date")["n_posts"].sum().reindex(all_days).fillna(0.0)
    # VECTORISED 2026-08-05. This was a `groupby("date").apply(lambda ...)`
    # which, on the 306k-row sentiment store, cost 482 ms PER INSTRUMENT
    # against 2 ms for the line below - the same arithmetic, done once per
    # group in Python instead of once in C. Across 59 instruments and two
    # callers that was ~84 s of pure interpreter overhead in every full
    # analytics run. Verified `.equals()` identical before the swap.
    nb = ((one["n_posts"] * one["net_bullish"]).groupby(one["date"]).sum()
          .reindex(all_days).fillna(0.0))
    share14 = (nb.rolling(14, min_periods=7).sum()
               / n.rolling(14, min_periods=7).sum().replace(0, np.nan))
    o3 = trailing_pct_rank(share14.diff(14))

    # O4: E3 at double speed - the crowd influx over 14d, not 28d
    o4 = trailing_pct_rank(share.diff(14))

    # O5: the super-exponential attention signature (shared with E5 -
    # contagion accelerating is an EARLY-phase phenomenon)
    o5 = trailing_pct_rank(log_convexity(1.0 + m7).clip(lower=0))

    out = pd.DataFrame({"attention_accel": o1, "hype_ratio": o2,
                        "bull_inflection": o3, "influx_speed": o4,
                        "attention_convexity": o5,
                        # NOT a bank feature - the RAW hype ratio, kept so
                        # the onset prerequisite gate (share above its own
                        # 120d median, multiplier 1 = parameter-free) can
                        # be applied identically to every model
                        "hype_raw": share / base.where(base > 0)})
    if with_breadth and entity_col == "ticker":
        breadth = _source_breadth(name, all_days)
        if breadth is not None:
            out["source_breadth"] = trailing_pct_rank(breadth)
    return out


# ---------------------------------------------------------------------------
# 3. THE LABELLED DAY FRAME - the one table notebooks 02/03 both stand on
# ---------------------------------------------------------------------------
def label_days(index: pd.DatetimeIndex, episodes: pd.DataFrame,
               name: str) -> pd.DataFrame:
    """Three {0,1} labels for every day of one instrument's series:

    y_onset : day inside an episode's onset window [trough, capped end]
    y_late  : day inside (onset end, peak] - in the rally, past its start
    y_top   : day inside [peak - TOP_LEAD_DAYS, peak + 1d] - the existing
              aim window of the top detector
    """
    eps = episodes[episodes["name"] == name]
    y_onset = pd.Series(0, index=index)
    y_late = pd.Series(0, index=index)
    y_top = pd.Series(0, index=index)
    for ep in eps.itertuples():
        y_onset.loc[ep.onset_lo:ep.onset_hi] = 1
        if ep.onset_hi < ep.peak:
            y_late.loc[ep.onset_hi + pd.Timedelta(days=1):ep.peak] = 1
        y_top.loc[ep.peak - pd.Timedelta(days=TOP_LEAD_DAYS):
                  ep.peak + pd.Timedelta(days=1)] = 1
    return pd.DataFrame({"y_onset": y_onset, "y_late": y_late,
                         "y_top": y_top})


def build_day_frame(series: list, pxmap: dict,
                    episodes: pd.DataFrame,
                    counts: dict, sents: dict,
                    clip_judgeable: bool = True) -> pd.DataFrame:
    """One row per (instrument, candidate day): every onset feature, every
    incumbent feature, and the three labels. Candidate days are the days
    the detector is even allowed to speak on - coverage gate satisfied
    AND inside the judgeable price window (an unjudgeable label is
    missing data, not truth). counts/sents map entity_col -> long frame,
    e.g. {"theme": theme_counts, "ticker": tick_counts}.

    clip_judgeable=False keeps the most recent ~45 days (whose labels
    cannot be judged yet - alerts there are PENDING, not false): research
    must clip them, but the LIVE dashboard must score them."""
    by_src = load(TICKER_COUNTS_BY_SOURCE)
    if by_src is not None:
        by_src = by_src.assign(date=pd.to_datetime(by_src["date"]))
    frames = []
    for es in series:
        entity_col = "theme" if es.kind == "theme" else "ticker"
        onset = compute_onset_features(
            es.name, counts[entity_col], sents[entity_col], entity_col,
            by_source=by_src if entity_col == "ticker" else None)
        top = pd.DataFrame({"e1": es.e1, "e2": es.e2, "e3": es.e3,
                            "e5": es.e5, "fade": es.fade.astype(float),
                            # un-gated sentiment ingredients (ML bank)
                            "bull_level": es.bull_level,
                            "bull_persist": es.bull_persist})
        df = onset.join(top)
        labels = label_days(df.index, episodes, es.name)
        df = df.join(labels)
        # candidate-day mask: measurable (A0) and judgeable (price truth)
        j0, j1 = judgeable_window(pxmap[es.symbol])
        if j0 is None:
            continue
        ok = es.coverage_ok.reindex(df.index).fillna(False).astype(bool)
        mask = ok & (df.index >= j0)
        if clip_judgeable:
            mask = mask & (df.index <= j1)
        df = df[mask]
        # features must exist (percentiles need EUPHORIA_MIN_HISTORY days)
        df = df.dropna(subset=[c for c in (ONSET_FEATURES + TOP_FEATURES
                                           + ["bull_level", "bull_persist"])
                               if c in df.columns
                               and c not in ("source_breadth", "hype_raw")])
        if df.empty:
            continue
        df = df.assign(name=es.name, kind=es.kind, year=df.index.year,
                       hype_ok=es.boom_ok.reindex(df.index)
                       .fillna(False).astype(bool))
        frames.append(df.reset_index(names="date"))
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


# ---------------------------------------------------------------------------
# 4. TOURNAMENT MACHINERY - walk-forward model comparison (notebook 03),
#    written here so the production detector runs the WINNING code path,
#    not a re-implementation of it.
# ---------------------------------------------------------------------------
from src.config import EUPHORIA_COOLDOWN_DAYS  # noqa: E402  (single source)


def alerts_from_scores(dates: list, scores: list, threshold: float,
                       cooldown: int = EUPHORIA_COOLDOWN_DAYS) -> list:
    """Scores -> sparse alert dates: fire on score >= threshold, then
    apply the standard cooldown (same rule as the top detector's A4).
    Only the threshold crossings are scanned (the cooldown pass is
    inherently sequential, but crossings are rare by construction)."""
    s = np.asarray(scores, dtype=float)
    alerts, last = [], None
    for i in np.flatnonzero(s >= threshold):
        d = dates[i]
        if last is None or (d - last).days >= cooldown:
            alerts.append(d)
            last = d
    return alerts


def alerts_from_scores_shaped(dates: list, scores: list, gate,
                              threshold: float, rearm: float,
                              spacing: int) -> list:
    """The SHAPED trigger (desk decision 2026-08-09 v2, evidence
    docs/research/alert_shape_sweep.json - "one clear call per boom"):

    * fire only on an UPWARD CROSSING of the cut, and only on days the
      PHASE GATE allows (GET OUT: the name has already boomed by the
      ground truth's own 120d bar; GET IN: it has not);
    * after a fire, the score must drop below the RE-ARM level before
      it may fire again (GET OUT re-arms at the cut; GET IN re-arms at
      the train-median score - the crowd must fully cool);
    * one call per name per `spacing` days (63 - one per quarter).

    Walk-forward, this took GET OUT from 305 calls / 1.6-per-boom to
    130 calls / 1.2-per-boom at precision 0.36 -> 0.53, and made
    IN-vs-OUT adjacency structurally impossible outside the bar-crossing
    moment (the display layer then drops the few INs that remain within
    21d of an OUT)."""
    s = np.asarray(scores, dtype=float)
    g = np.asarray(gate, dtype=bool)
    alerts, last, armed = [], None, True
    for d, v, ok in zip(dates, s, g):
        if v >= threshold:
            if ok and armed and (last is None
                                 or (d - last).days >= spacing):
                alerts.append(d)
                last = d
            armed = False
        elif v < rearm:
            armed = True
    return alerts


def boomed120_frame(series, pxmap) -> pd.DataFrame:
    """name/date/boomed120: run-up vs the trailing 120d low >= the G2
    boom bar (20% themes / 40% singles) - the EPISODE DEFINITION's own
    boom test, reused as the alert phase gate (no new constant). A top
    may only be called after a boom as the ground truth defines booms;
    a start only before the boom has completed."""
    from src.config import (EUPHORIA_BOOM_MIN_ETF,
                            EUPHORIA_BOOM_MIN_SINGLE)
    rows = []
    for es in series:
        px = pxmap[es.symbol].dropna().asfreq("D").ffill()
        low120 = px.rolling(120, min_periods=60).min()
        bar = (EUPHORIA_BOOM_MIN_SINGLE if es.kind == "single"
               else EUPHORIA_BOOM_MIN_ETF)
        rows.append(pd.DataFrame({
            "name": es.name, "date": px.index,
            "boomed120": ((px / low120 - 1) >= bar).values}))
    return pd.concat(rows, ignore_index=True)


def _day_ints(x) -> np.ndarray:
    """Timestamps -> integer day numbers. Every judging comparison below
    runs in int64 day-space: the cooldown/tally sweep is called thousands
    of times per tournament, and Timestamp arithmetic in a Python loop is
    ~50x slower than integer arithmetic."""
    return (pd.DatetimeIndex(x).values.astype("datetime64[D]")
            .astype(np.int64))


def _eps_arrays(eps: pd.DataFrame) -> dict:
    """One instrument's episodes as parallel int-day arrays."""
    return {"trough": _day_ints(eps["trough"]) if len(eps) else np.array([], np.int64),
            "lo": _day_ints(eps["onset_lo"]) if len(eps) else np.array([], np.int64),
            "hi": _day_ints(eps["onset_hi"]) if len(eps) else np.array([], np.int64),
            "peak": _day_ints(eps["peak"]) if len(eps) else np.array([], np.int64)}


def classify_onset_alerts(alert_days: np.ndarray, ea: dict) -> dict:
    """Judge one instrument's onset alerts (int days) against its
    episodes (int-day arrays from _eps_arrays).

    HIT  : alert inside [onset_lo, onset_hi] (each episode captured once);
    LATE : alert inside (onset_hi, peak] - in the rally, past its start;
    FA   : everything else.
    Leads are recorded both ways: days after the trough, days before the
    peak."""
    captured, late, fa, leads = set(), [], [], []
    for a in alert_days:
        hit = np.flatnonzero((ea["lo"] <= a) & (a <= ea["hi"]))
        if hit.size:
            for i in hit:
                p = int(ea["peak"][i])
                if p not in captured:
                    captured.add(p)
                    leads.append({"peak": p,
                                  "after_trough": int(a - ea["trough"][i]),
                                  "before_peak": int(p - a)})
            continue
        if np.any((ea["hi"] < a) & (a <= ea["peak"])):
            late.append(int(a))
        else:
            fa.append(int(a))
    return {"captured": captured, "late": late, "fa": fa, "leads": leads}


def classify_top_alerts(alert_days: np.ndarray, ea: dict) -> dict:
    """Judge one instrument's top alerts - the existing aim, unchanged:
    HIT = alert inside [peak-30d, peak+1d]; FA = no episode peak within
    [alert, alert+45d]. (Structurally parallel to the onset judge.)"""
    captured, fa, leads = set(), [], []
    for a in alert_days:
        hit = np.flatnonzero((ea["peak"] - TOP_LEAD_DAYS <= a)
                             & (a <= ea["peak"] + 1))
        if hit.size:
            for i in hit:
                p = int(ea["peak"][i])
                if p not in captured:
                    captured.add(p)
                    leads.append({"peak": p, "before_peak": int(p - a)})
            continue
        if not np.any((ea["peak"] >= a) & (ea["peak"] <= a + 45)):
            fa.append(int(a))
    return {"captured": captured, "late": [], "fa": fa, "leads": leads}


def walk_forward_scores(frame: pd.DataFrame, feats: list, label: str,
                        fit_score) -> pd.DataFrame:
    """The walk-forward spine shared by every model in the tournament.

    For each test year y (needing >= 3 positive days in the years before,
    the existing ml_walk_forward convention): fit on years < y, score both
    the train years (threshold selection evidence) and year y (the test).
    fit_score(train_df, apply_df, feats) -> score array on apply_df; a
    rule-based model simply ignores train_df. Returns the frame plus
    'score' and 'test_year' columns, test rows only, all years stacked."""
    out = []
    years = sorted(frame.year.unique())
    for y in years:
        train = frame[frame.year < y]
        test = frame[frame.year == y]
        if train[label].sum() < 3 or test.empty:
            continue
        out.append(test.assign(score=fit_score(train, test, feats),
                               train_score=np.nan, test_year=y))
    return (pd.concat(out, ignore_index=True) if out
            else pd.DataFrame(columns=list(frame.columns) + ["score",
                                                             "test_year"]))


def _alerts_int(days: np.ndarray, scores: np.ndarray, threshold: float,
                cooldown: int = EUPHORIA_COOLDOWN_DAYS) -> np.ndarray:
    """alerts_from_scores in int-day space (the tournament hot path)."""
    alerts, last = [], None
    for i in np.flatnonzero(scores >= threshold):
        if last is None or days[i] - last >= cooldown:
            alerts.append(days[i])
            last = days[i]
    return np.asarray(alerts, dtype=np.int64)


def _pregroup(scored: pd.DataFrame, episodes: pd.DataFrame) -> dict:
    """Group once, tally many times: {name: (day_ints, scores,
    eps_int_arrays)}. Threshold sweeps re-scan these arrays instead of
    re-grouping frames."""
    eps_by = dict(tuple(episodes.groupby("name")))
    empty = episodes.iloc[0:0]
    return {name: (_day_ints(g["date"]),
                   g["score"].to_numpy(dtype=float),
                   _eps_arrays(eps_by.get(name, empty)))
            for name, g in scored.sort_values("date").groupby("name")}


def _tally(groups: dict, episodes: pd.DataFrame, threshold: float,
           mode: str, denominator_mask) -> dict:
    """Alerts at one threshold -> operational scorecard, pooled over all
    the scored rows. mode: 'onset' | 'top'."""
    judge = classify_onset_alerts if mode == "onset" else classify_top_alerts
    det_col = "onset_detectable" if mode == "onset" else "top_detectable"
    captured, late, fa, leads = set(), [], [], []
    for name, (days, scores, ea) in groups.items():
        alerts = _alerts_int(days, scores, threshold)
        if not alerts.size:
            continue
        res = judge(alerts, ea)
        captured |= {(name, p) for p in res["captured"]}
        late += res["late"]; fa += res["fa"]; leads += res["leads"]
    det = episodes[denominator_mask(episodes) & episodes[det_col]]
    det_keys = {(r.name, int(p)) for r, p in
                zip(det.itertuples(), _day_ints(det["peak"]))}
    hits = len(captured & det_keys)
    return {"captured": hits, "detectable": len(det_keys),
            "late": len(late), "false_alarms": len(fa), "leads": leads}


def choose_threshold(train_scored: pd.DataFrame, episodes: pd.DataFrame,
                     mode: str, fa_budget_per_iy: float,
                     n_instruments: int) -> float:
    """The PRE-STATED criterion, applied on TRAINING years only:
    among percentile thresholds of the train scores, keep those whose
    train FA rate is within the budget; of those, maximise captured;
    tie -> the more conservative (higher) threshold. If nothing fits the
    budget, the most conservative threshold wins (do-no-harm default -
    the same convention as euphoria.walk_forward)."""
    years = sorted(train_scored.year.unique())
    n_iy = max(n_instruments * len(years), 1)
    in_years = lambda eps: eps.year.isin(years)  # noqa: E731
    grid = np.unique(np.percentile(train_scored["score"].dropna(),
                                   np.arange(50, 100, 2.5)))
    groups = _pregroup(train_scored, episodes)
    best_thr, best_key = grid[-1], (-1, -np.inf)
    for thr in grid[::-1]:                     # conservative first
        r = _tally(groups, episodes, thr, mode, in_years)
        if r["false_alarms"] / n_iy > fa_budget_per_iy:
            continue
        key = (r["captured"], thr)             # capture, then conservatism
        if key > best_key:
            best_key, best_thr = key, thr
    return float(best_thr)


def run_tournament_entry(frame: pd.DataFrame, episodes: pd.DataFrame,
                         feats: list, label: str, mode: str,
                         fit_score, fa_budget_per_iy: float,
                         chooser=None) -> dict:
    """One model through the whole discipline: walk-forward scores, a
    threshold chosen per test year on its train years only, alerts,
    pooled scorecard + threshold-independent AP/AUROC on the stacked
    test scores - which keeps score QUALITY (AP/AUROC, threshold-free)
    separate from the OPERATING POINT chosen on it.

    chooser: the threshold-selection rule, called as
    chooser(train_scored, episodes, mode, fa_budget_per_iy,
    n_instruments). None = the incumbent FA-budget rule
    (choose_threshold); the ML tournament passes its budget-free F1
    chooser (analytics.ml_detector.choose_threshold_f1)."""
    from sklearn.metrics import roc_auc_score, average_precision_score

    if chooser is None:
        chooser = choose_threshold
    n_instruments = frame["name"].nunique()
    scored = walk_forward_scores(frame, feats, label, fit_score)
    if scored.empty:
        return {"error": "no scoreable years"}
    test_years = sorted(scored.test_year.unique())

    # thresholds are chosen per test year, on that year's TRAIN years -
    # scored again by the same fitted model (rule models are identical)
    parts = []
    thresholds = {}
    for y in test_years:
        train = frame[frame.year < y]
        train_scored = train.assign(
            score=fit_score(train, train, feats))
        thr = chooser(train_scored, episodes, mode,
                      fa_budget_per_iy, n_instruments)
        thresholds[int(y)] = thr
        parts.append(scored[scored.test_year == y].assign(threshold=thr))
    test = pd.concat(parts, ignore_index=True)

    # operational scorecard: each year's alerts at its own threshold
    eps_by = dict(tuple(episodes.groupby("name")))
    empty = episodes.iloc[0:0]
    per_name_alerts: dict[str, list] = {}
    captured, late, fa, leads = set(), [], [], []
    judge = classify_onset_alerts if mode == "onset" else classify_top_alerts
    for (name, y), g in test.groupby(["name", "test_year"]):
        g = g.sort_values("date")
        alerts = _alerts_int(_day_ints(g["date"]),
                             g["score"].to_numpy(dtype=float),
                             g["threshold"].iloc[0])
        per_name_alerts.setdefault(name, []).extend(alerts.tolist())
    for name, alerts in per_name_alerts.items():
        ea = _eps_arrays(eps_by.get(name, empty))
        res = judge(np.asarray(sorted(alerts), dtype=np.int64), ea)
        captured |= {(name, p) for p in res["captured"]}
        late += res["late"]; fa += res["fa"]; leads += res["leads"]

    det_col = "onset_detectable" if mode == "onset" else "top_detectable"
    det = episodes[episodes.year.isin(test_years) & episodes[det_col]]
    det_keys = {(r.name, int(p)) for r, p in
                zip(det.itertuples(), _day_ints(det["peak"]))}
    n_iy = max(n_instruments * len(test_years), 1)
    y_true, y_score = test[label].values, test["score"].values
    hits = len(captured & det_keys)

    def _ts(day: int) -> pd.Timestamp:
        return pd.Timestamp(np.datetime64(int(day), "D"))

    return {
        "test_years": [int(y) for y in test_years],
        "thresholds": thresholds,
        "captured": hits, "detectable": len(det_keys),
        "capture_rate": round(hits / len(det_keys), 3) if det_keys else None,
        "late": len(late), "false_alarms": len(fa),
        "fa_per_iy": round(len(fa) / n_iy, 3),
        "leads": leads,
        "auroc": round(float(roc_auc_score(y_true, y_score)), 3)
        if len(set(y_true)) > 1 else None,
        "ap": round(float(average_precision_score(y_true, y_score)), 3)
        if len(set(y_true)) > 1 else None,
        "ap_baseline": round(float(np.mean(y_true)), 3),
        "alerts_by_name": {k: [_ts(a) for a in v]
                           for k, v in per_name_alerts.items() if v},
    }


# ---------------------------------------------------------------------------
# 5. PRODUCTION - the live onset detector (the NB03 tournament winner:
#    the RULES model - un-weighted mean of ONSET_BANK - which beat every
#    learner under the pre-stated criterion). Called from run_analytics on
#    every rebuild, exactly like the top detector.
# ---------------------------------------------------------------------------
def onset_score(df: pd.DataFrame) -> pd.Series:
    """The winning onset score: the un-weighted mean of the locked bank
    (the euphoria-LEVEL construction applied to the onset features).
    Takes NO price argument, by design - enforced by a unit test."""
    return df[ONSET_BANK].mean(axis=1)


def _stored_onset_report() -> dict | None:
    import json as _json
    import os as _os
    from src.config import PROCESSED_DIR
    path = _os.path.join(PROCESSED_DIR, "euphoria_onset_report.json")
    if not _os.path.exists(path):
        return None
    try:
        return _json.load(open(path))
    except (ValueError, OSError):
        return None


def onset_needs_research(stored: dict | None, data_max_year: int) -> bool:
    """Mirror of euphoria.needs_research, and it moved on the same date
    for the same reasons: a data pull derives a threshold for itself in
    EXACTLY ONE case - there is no usable frozen record to read. A
    record that exists but stops at an earlier year is not a reason to
    re-fit inside a refresh job; it is a reason to print a notice (see
    `onset_record_lags_data`) and let the desk spend a `--research` run
    when it chooses. Full argument in analytics/euphoria.py's
    `needs_research`; recorded in DECISIONS.xlsx ("2. Pipeline &
    Cadence")."""
    if not stored or "live_threshold" not in stored:
        return True
    return not (stored.get("walk_forward", {}).get("test_years") or [])


def onset_record_lags_data(stored: dict | None, data_max_year: int):
    """Newest walk-forward test year when it lags the data, else None."""
    if not stored or "live_threshold" not in stored:
        return None
    years = stored.get("walk_forward", {}).get("test_years") or []
    if not years:
        return None
    newest = max(int(y) for y in years)
    return newest if data_max_year > newest else None


def rebuild_phase_files(verbose: bool = True,
                        research: bool | None = None) -> dict:
    """Rebuild what the dashboard's start/end panes read.

    LIVE mode (the pipeline default whenever a frozen record exists at
    all): build today's features, score at the FROZEN live threshold,
    refresh episodes.parquet + euphoria_onset.parquet. Seconds beyond
    the unavoidable feature build; the stored walk-forward scorecard is
    left untouched (it is a research artifact with an as-of range, not a
    daily statistic). A record that lags the data prints one notice and
    is still used - see `onset_needs_research` for why that is the
    methodologically correct default, not a shortcut.

    RESEARCH mode (research=True, or the one-off bootstrap when
    onset_needs_research finds no record): additionally re-runs the
    winner's full
    walk-forward scorecard and re-selects the live threshold - on FULL
    years strictly before the current data year (the incumbent's
    convention, so the threshold is stable within a year by
    construction) - and rewrites euphoria_onset_report.json."""
    import json as _json
    import os as _os

    from src.config import PRICES_PATH, PROCESSED_DIR
    from analytics.euphoria import build_all_series
    from analytics.loaders import load as _load, THEME_COUNTS, THEME_SENT, \
        TICKER_COUNTS, TICKER_SENT

    prices = pd.read_parquet(PRICES_PATH)
    prices["date"] = pd.to_datetime(prices["date"])
    series, pxmap = build_all_series(prices)
    episodes = episode_catalog(series, pxmap)

    counts = {"theme": _load(THEME_COUNTS), "ticker": _load(TICKER_COUNTS)}
    sents = {"theme": _load(THEME_SENT), "ticker": _load(TICKER_SENT)}
    for d in list(counts.values()) + list(sents.values()):
        d["date"] = pd.to_datetime(d["date"])

    # the LIVE frame (through today - recent alerts are PENDING, not
    # false) is needed in both modes; it is the unavoidable cost
    frame_live = build_day_frame(series, pxmap, episodes, counts, sents,
                                 clip_judgeable=False)
    onset_live = frame_live[frame_live.hype_raw >= 1].copy()
    data_max_year = int(pd.to_datetime(frame_live["date"]).max().year)

    stored = _stored_onset_report()
    if research is None:
        research = onset_needs_research(stored, data_max_year)
        if research and verbose:
            print("  onset: no frozen record here - deriving the "
                  "threshold once (bootstrap)")
        elif verbose:
            _lag = onset_record_lags_data(stored, data_max_year)
            if _lag is not None:
                print(f"  NOTE: onset data reaches {data_max_year}; the "
                      f"frozen threshold was confirmed through {_lag}. "
                      "Scoring at it out-of-sample, as designed. Refresh "
                      "the record deliberately with "
                      "analytics.run_analytics --what phases --research")

    if research:
        # the JUDGED frame (labels need 45d of future price) powers the
        # honest scorecard + threshold selection
        frame = build_day_frame(series, pxmap, episodes, counts, sents)
        onset_frame = frame[frame.hype_raw >= 1].copy()

        # THE FA BUDGET IS A CONSTANT, not a reading off the last run.
        # It used to be loaded from euphoria_report.json here, which
        # raced with the euphoria stage rewriting that file in parallel
        # and made the adoption bar depend on stage finishing order.
        # See the block beside EUPHORIA_FA_BUDGET_PER_IY in src/config.py.
        fa_budget = EUPHORIA_FA_BUDGET_PER_IY

        def _rules(train, apply, feats):
            return onset_score(apply).values

        wf = run_tournament_entry(onset_frame, episodes, ONSET_BANK,
                                  "y_onset", "onset", _rules, fa_budget)

        # live threshold from FULL years strictly before the current
        # data year - stable within a year by construction
        train = onset_frame[onset_frame["year"] < data_max_year]
        if train.empty:                      # very young data: use all
            train = onset_frame
        train_scored = train.assign(score=onset_score(train))
        thr_live = choose_threshold(train_scored, episodes, "onset",
                                    fa_budget, train["name"].nunique())
        stored = {
            "live_threshold": thr_live,
            "fa_budget_per_iy": fa_budget,
            "walk_forward": {k: v for k, v in wf.items()
                             if k not in ("leads", "alerts_by_name")},
            "onset_window_days": ONSET_WINDOW_DAYS,
            "bank": ONSET_BANK,
        }
        with open(_os.path.join(PROCESSED_DIR,
                                "euphoria_onset_report.json"), "w") as f:
            _json.dump(stored, f, indent=1, default=str)
        if verbose:
            print(f"  onset RESEARCH pass: {wf['captured']}/"
                  f"{wf['detectable']} detectable onsets captured, "
                  f"{wf['late']} late, {wf['false_alarms']} FA "
                  f"({wf['fa_per_iy']}/instr-yr vs budget {fa_budget}) | "
                  f"live threshold {thr_live:.3f}")
    else:
        thr_live = float(stored["live_threshold"])
        if verbose:
            print(f"  onset LIVE mode: frozen threshold {thr_live:.3f} "
                  "(intra-year recompute is a no-op by the walk-forward "
                  "convention). Full validation: run_analytics --what "
                  "phases --research")

    # daily score + alert table for the dashboard (both modes)
    live_scored = onset_live.assign(score=onset_score(onset_live))
    rows = []
    for name, g in live_scored.sort_values("date").groupby("name"):
        alerts = set(alerts_from_scores(g["date"].tolist(),
                                        g["score"].tolist(), thr_live))
        cols = {
            "date": g["date"].values, "name": name,
            "kind": g["kind"].values,
            # "onset_score", not "score": the FORBIDDEN-columns contract
            # reserves "score" for the raw Reddit post field it bans
            "onset_score": g["score"].values,
            # raw hype ratio (7d share / own 120d median) so the
            # dashboard can hold single names to the FULL A1 bar (2x)
            # for display - "really euphoric", not marginal flicker
            "hype_raw": g["hype_raw"].values,
            "alert": g["date"].isin(alerts).values}
        # the bank components, so the dashboard can EXPLAIN each onset
        for c in ONSET_BANK:
            cols[c] = g[c].values
        rows.append(pd.DataFrame(cols))
    out = pd.concat(rows, ignore_index=True)
    sym_by = {es.name: es.symbol for es in series}
    out["symbol"] = out["name"].map(sym_by)

    from src.abstracted_data import _safe_write
    _safe_write(episodes, _os.path.join(PROCESSED_DIR, "episodes.parquet"))
    _safe_write(out, _os.path.join(PROCESSED_DIR, "euphoria_onset.parquet"))
    if verbose:
        print(f"  saved episodes.parquet ({len(episodes)}), "
              f"euphoria_onset.parquet ({len(out):,})")

    # ---- THE DESK CONFIGURATION (GET IN / GET OUT - section 6) ----------
    # The dashboard's headline signals. Research passes re-run the full
    # walk-forward for both desk detectors and refreeze their thresholds;
    # live passes score today's data at the frozen thresholds in seconds.
    boom = boom_state_frame(series, pxmap)
    fpx_live = frame_live.merge(boom, on=["name", "date"], how="left")
    # astype(bool) after the fill: the merge leaves an object column
    # holding True/False/NaN, and pandas 2.x deprecated silently
    # downcasting that back to bool on fillna. Saying the dtype out loud
    # keeps the behaviour identical and drops the FutureWarning.
    fpx_live["boom_state"] = (fpx_live["boom_state"]
                              .fillna(False).astype(bool))

    desk_path = _os.path.join(PROCESSED_DIR, "euphoria_desk_report.json")
    desk_stored = None
    if _os.path.exists(desk_path):
        try:
            desk_stored = _json.load(open(desk_path))
        except (ValueError, OSError):
            desk_stored = None
    desk_research = research or desk_needs_research(desk_stored,
                                                    data_max_year)
    _desk_lag = (None if desk_research
                 else desk_record_lags_data(desk_stored, data_max_year))

    fa_budget = EUPHORIA_FA_BUDGET_PER_IY      # frozen - see src/config.py

    # THE DESK MODEL IS SELECTED, NOT ASSUMED (2026-08-07). A research
    # pass runs the full model tournament (analytics/ml_detector.py:
    # incumbent rules + logistic + monotone GBM + MLP + ensemble, all
    # walk-forward) and freezes the winner under the pre-stated
    # criterion (one family for both heads, combined AP lift). Live
    # passes re-fit the frozen family deterministically on full years
    # strictly before the data year (same convention as every frozen
    # threshold here) and score today at the frozen probability cut.
    from analytics import ml_detector as mld    # local: avoids cycle

    frame_j = None

    def _judged_frame():
        nonlocal frame_j
        if frame_j is None:
            frame_j = (frame if research
                       else build_day_frame(series, pxmap, episodes,
                                            counts, sents))
        return frame_j

    def _frozen_ml(cand_j, maker, label, mode, chooser=None):
        train = cand_j[cand_j["year"] < data_max_year]
        if train.empty:                        # very young data: use all
            train = cand_j
        fit = maker(label)
        train_scored = train.assign(score=fit(train, train,
                                              mld.DESK_ML_BANK))
        chooser = chooser or mld.choose_threshold_f1
        return chooser(train_scored, episodes, mode, fa_budget,
                       train["name"].nunique())

    def _frozen_ml_pair(cand_j, maker, label, mode):
        """(standard F1 cut, strict F0.5 cut, train-median re-arm level)
        from ONE train scoring. The re-arm level is the GET IN trigger's
        'the crowd must fully cool before another start call' floor
        (desk decision 2026-08-09 v2)."""
        train = cand_j[cand_j["year"] < data_max_year]
        if train.empty:
            train = cand_j
        fit = maker(label)
        train_scored = train.assign(score=fit(train, train,
                                              mld.DESK_ML_BANK))
        n = train["name"].nunique()
        return (mld.choose_threshold_f1(train_scored, episodes, mode,
                                        fa_budget, n),
                mld.choose_threshold_strict(train_scored, episodes, mode,
                                            fa_budget, n),
                float(np.percentile(train_scored["score"].dropna(), 50)))

    if desk_research:
        fj = _judged_frame()
        tournament = mld.run_ml_tournament(fj, episodes, pxmap, sym_by,
                                           series=series, boom=boom)
        model_name = mld.pick_winner(tournament)
        wf_out = tournament["get_out"][model_name]
        wf_in = tournament["get_in"][model_name]

        if model_name == "rules":
            fpx_j = fj.merge(boom, on=["name", "date"], how="left")
            fpx_j["boom_state"] = (fpx_j["boom_state"]
                                   .fillna(False).astype(bool))
            end_j, onset_j = desk_candidacy(fpx_j)

            def _frozen(cand, fit, feats, mode):
                train = cand[cand["year"] < data_max_year]
                if train.empty:                # very young data: use all
                    train = cand
                train_scored = train.assign(score=fit(train, train, feats))
                return choose_threshold(train_scored, episodes, mode,
                                        fa_budget,
                                        train["name"].nunique())

            thr_out = _frozen(end_j, desk_end_fit, TOP_FEATURES, "top")
            thr_in = _frozen(onset_j, desk_onset_fit, ONSET_BANK, "onset")
            thr_out_strict = thr_in_strict = None   # strict = ML-only
            rearm_in = None
        else:
            cand_j = mld.attach_price_features(
                mld.candidate_frame(fj), series, pxmap)
            maker = mld.ML_FITS[model_name]
            thr_out, thr_out_strict, _ = _frozen_ml_pair(
                cand_j, maker, "y_top", "top")
            thr_in, thr_in_strict, rearm_in = _frozen_ml_pair(
                cand_j, maker, "y_onset", "onset")

        # a compact copy of the whole tournament rides in the record so
        # the dashboard can show the comparison table without re-running
        _tbl_keys = ("auroc", "ap", "ap_baseline", "captured",
                     "detectable", "capture_rate", "late",
                     "false_alarms", "fa_per_iy", "precision",
                     "median_lead_days", "n_alerts", "forward_returns",
                     "test_years")
        _tbl = {h: {m: {k: r.get(k) for k in _tbl_keys}
                    for m, r in tournament[h].items() if "error" not in r}
                for h in ("get_out", "get_in")}
        desk_stored = {
            "model": model_name,
            "get_out": {"live_threshold": thr_out,
                        "strict_threshold": thr_out_strict,
                        "walk_forward": wf_out},
            "get_in": {"live_threshold": thr_in,
                       "strict_threshold": thr_in_strict,
                       "rearm_level": rearm_in,
                       "walk_forward": wf_in},
            "conditioning": {
                "version": 2,
                "trigger": "shaped crossing (phase gates + re-arm + "
                           "63d spacing)",
                "get_out": "only after the 120d G2 boom bar; re-arms "
                           "at the cut",
                "get_in": "only before the boom completes; re-arms at "
                          "the train-median score",
                "separation": "no GET IN within 21d of a GET OUT, "
                              "either direction",
                "standard": "F1 cut",
                "strict": "F0.5 cut (precision weighted 2x)",
                "evidence": "docs/research/alert_shape_sweep.json",
                "decided": "2026-08-09",
            },
            "tournament": _tbl,
            "selection_rule": ("one family for both heads; combined "
                               "test AP lift; ties AUROC then fewer "
                               "false alarms"),
            "operating_point_rule": ("probability cut maximising "
                                     "episode-level F1 on train years"
                                     if model_name != "rules" else
                                     "incumbent FA-budget rule"),
            "fa_budget_per_iy": fa_budget,
            "smooth_days": ROLL,
            "bank_get_out": (mld.DESK_ML_BANK if model_name != "rules"
                             else TOP_FEATURES),
            "bank_get_in": (mld.DESK_ML_BANK if model_name != "rules"
                            else ONSET_BANK),
        }
        with open(desk_path, "w") as f:
            _json.dump(desk_stored, f, indent=1, default=str)
        if verbose:
            print(f"  DESK research pass (winner: {model_name}): GET OUT "
                  f"cap {wf_out['captured']}/{wf_out['detectable']} FA "
                  f"{wf_out['false_alarms']} AP {wf_out['ap']} | GET IN "
                  f"cap {wf_in['captured']}/{wf_in['detectable']} late "
                  f"{wf_in['late']} FA {wf_in['false_alarms']} | frozen "
                  f"thr in {thr_in:.3f} / out {thr_out:.3f}")
    else:
        model_name = (desk_stored or {}).get("model", "rules")
        thr_out = float(desk_stored["get_out"]["live_threshold"])
        thr_in = float(desk_stored["get_in"]["live_threshold"])
        thr_out_strict = desk_stored["get_out"].get("strict_threshold")
        thr_in_strict = desk_stored["get_in"].get("strict_threshold")
        rearm_in = desk_stored["get_in"].get("rearm_level")
        _cond_v = (desk_stored.get("conditioning") or {}).get("version")
        if model_name != "rules" and (_cond_v != 2
                                      or thr_out_strict is None
                                      or thr_in_strict is None
                                      or rearm_in is None):
            # upgrade an older record in place: derive the strict cuts
            # and the GET IN re-arm level once, persist them
            cand_up = mld.attach_price_features(
                mld.candidate_frame(_judged_frame()), series, pxmap)
            maker_up = mld.ML_FITS[model_name]
            thr_out2, thr_out_strict, _ = _frozen_ml_pair(
                cand_up, maker_up, "y_top", "top")
            thr_in2, thr_in_strict, rearm_in = _frozen_ml_pair(
                cand_up, maker_up, "y_onset", "onset")
            desk_stored["get_out"]["strict_threshold"] = thr_out_strict
            desk_stored["get_in"]["strict_threshold"] = thr_in_strict
            desk_stored["get_in"]["rearm_level"] = rearm_in
            desk_stored["conditioning"] = {
                "version": 2,
                "trigger": "shaped crossing (phase gates + re-arm + "
                           "63d spacing)",
                "get_out": "only after the 120d G2 boom bar; re-arms "
                           "at the cut",
                "get_in": "only before the boom completes; re-arms at "
                          "the train-median score",
                "separation": "no GET IN within 21d of a GET OUT, "
                              "either direction",
                "standard": "F1 cut",
                "strict": "F0.5 cut (precision weighted 2x)",
                "evidence": "docs/research/alert_shape_sweep.json",
                "decided": "2026-08-09",
            }
            with open(desk_path, "w") as f:
                _json.dump(desk_stored, f, indent=1, default=str)
            if verbose:
                print(f"  desk record upgraded to conditioning v2 "
                      f"(strict in {thr_in_strict:.3f} / out "
                      f"{thr_out_strict:.3f}; GET IN re-arm "
                      f"{rearm_in:.3f})")
        if verbose:
            print(f"  DESK live mode ({model_name}): frozen thresholds "
                  f"in {thr_in:.3f} / out {thr_out:.3f}")
            if _desk_lag is not None:
                print(f"  NOTE: desk data reaches {data_max_year}; these "
                      f"thresholds were confirmed through {_desk_lag}. "
                      "Refresh the record deliberately with "
                      "analytics.run_analytics --what phases --research")

    if model_name == "rules":
        end_live, onset_live_f = desk_candidacy(fpx_live)
        end_scored = end_live.assign(
            dscore=desk_end_fit(end_live, end_live, TOP_FEATURES))
        onset_scored = onset_live_f.assign(
            dscore=desk_onset_fit(onset_live_f, onset_live_f, ONSET_BANK))
    else:
        # ML path: candidacy is the coverage gate only - the hype, boom
        # and end-stage doors are FEATURES now, not gates
        cand_j = mld.attach_price_features(
            mld.candidate_frame(_judged_frame()), series, pxmap)
        train = cand_j[cand_j["year"] < data_max_year]
        if train.empty:
            train = cand_j
        live_cand = mld.attach_price_features(
            mld.candidate_frame(fpx_live), series, pxmap)
        maker = mld.ML_FITS[model_name]
        end_scored = live_cand.assign(
            dscore=maker("y_top")(train, live_cand, mld.DESK_ML_BANK))
        onset_scored = live_cand.assign(
            dscore=maker("y_onset")(train, live_cand, mld.DESK_ML_BANK))
        # the explainability sidecar the dashboard's "what drives the
        # calls" expander reads: logit weights + GBM permutation
        # importance for the live fit (one computation, every surface -
        # notebook 03 §SS2 shows the same two reads)
        try:
            insight = mld.model_insight(cand_j)
            insight["model"] = model_name
            with open(_os.path.join(PROCESSED_DIR,
                                    "desk_model_insight.json"), "w") as f:
                _json.dump(insight, f, indent=1)
            if verbose:
                print("  saved desk_model_insight.json (feature weights "
                      "for the dashboard)")
        except Exception as _e:                          # noqa: BLE001
            if verbose:
                print(f"  (model insight skipped: {_e})")

    # THE SHAPED TRIGGER (desk decision 2026-08-09 v2, evidence
    # docs/research/alert_shape_sweep.json): phase gates from the
    # ground truth's own 120d boom bar, re-arm levels, 63d spacing.
    from src.config import EUPHORIA_ALERT_SPACING_D
    _b120 = boomed120_frame(series, pxmap)

    def _alert_dates(scored, thr, rearm, gate_boomed):
        """gate_boomed True -> fire only after the boom (GET OUT);
        False -> only before it (GET IN). rearm None -> re-arm at the
        cut. Under the rules model the phase gates are already in the
        candidacy, so the gate defaults to open for missing rows."""
        by = {}
        sc = scored.merge(_b120, on=["name", "date"], how="left")
        sc["boomed120"] = sc["boomed120"].fillna(False).astype(bool)
        for name, g in sc.sort_values("date").groupby("name"):
            gate = (g["boomed120"] if gate_boomed
                    else ~g["boomed120"]).tolist()
            by[name] = set(alerts_from_scores_shaped(
                g["date"].tolist(), g["dscore"].tolist(), gate, thr,
                rearm if rearm is not None else thr,
                EUPHORIA_ALERT_SPACING_D))
        return by

    in_alerts = _alert_dates(onset_scored, thr_in, rearm_in, False)
    out_alerts = _alert_dates(end_scored, thr_out, None, True)
    in_alerts_s = (_alert_dates(onset_scored, thr_in_strict, rearm_in,
                                False)
                   if thr_in_strict is not None else {})
    out_alerts_s = (_alert_dates(end_scored, thr_out_strict, None, True)
                    if thr_out_strict is not None else {})

    ds = fpx_live[["date", "name", "kind", "hype_raw",
                   "boom_state"]].copy()
    ds["end_stage"] = end_stage_mask(fpx_live).values
    ds = ds.merge(onset_scored[["name", "date", "dscore"]]
                  .rename(columns={"dscore": "in_score"}),
                  on=["name", "date"], how="left")
    ds = ds.merge(end_scored[["name", "date", "dscore"]]
                  .rename(columns={"dscore": "out_score"}),
                  on=["name", "date"], how="left")
    for _suffix, _ia, _oa in (("", in_alerts, out_alerts),
                              ("_strict", in_alerts_s, out_alerts_s)):
        ds[f"get_in{_suffix}"] = [d in _ia.get(n, ())
                                  for n, d in zip(ds["name"], ds["date"])]
        ds[f"get_out{_suffix}"] = [d in _oa.get(n, ())
                                   for n, d in zip(ds["name"],
                                                   ds["date"])]
    # PM-TRUST COHERENCE (desk order 2026-08-09: "we CANNOT have a GET
    # IN and a GET OUT so close together"): a START is never shown on
    # an end-stage day, and never within one cooldown of an END call IN
    # EITHER DIRECTION. GET OUT is never suppressed - it is the risk
    # signal. The phase gates make same-day contradiction structurally
    # impossible; this rule sweeps the boundary cases. Applied to BOTH
    # the standard and the strict variant.
    for _suffix in ("", "_strict"):
        _gi, _go = f"get_in{_suffix}", f"get_out{_suffix}"
        ds.loc[ds["end_stage"].astype(bool), _gi] = False
        for _n, _g in ds.groupby("name"):
            outs = _g.loc[_g[_go], "date"]
            if not len(outs):
                continue
            ins = _g.loc[_g[_gi], "date"]
            for d in ins:
                if any(abs((d - t).days) <= EUPHORIA_COOLDOWN_DAYS
                       for t in outs):
                    ds.loc[(ds["name"] == _n) & (ds["date"] == d),
                           _gi] = False
    ds = ds.merge(_b120, on=["name", "date"], how="left")
    ds["boomed120"] = ds["boomed120"].fillna(False).astype(bool)
    ds["symbol"] = ds["name"].map(sym_by)
    _safe_write(ds, _os.path.join(PROCESSED_DIR, "euphoria_desk.parquet"))
    if verbose:
        print(f"  saved euphoria_desk.parquet ({len(ds):,} rows, "
              f"{int(ds['get_in'].sum())} GET IN / "
              f"{int(ds['get_out'].sum())} GET OUT alerts all-time, "
              f"model {model_name})")
    return stored


# ---------------------------------------------------------------------------
# 6. THE DESK CONFIGURATION (desk decision 2026-07-24) - the GET IN /
#    GET OUT signal family the dashboard actually shows.
#
#    The desk lifted the crowd-only restriction for a SECOND, clearly
#    labelled signal family ("we should be using both price and the
#    social media to predict - I want a better hit rate"). The crowd-only
#    detectors above are unchanged - their claim ("the crowd alone called
#    it") is different, not worse - and they remain the research
#    baseline every notebook still scores.
#
#    GET OUT (euphoria ending) = the incumbent rules score with two
#    measured upgrades (NB03 commissioned test + NB06):
#      * candidacy requires an ACTUAL PRICE BOOM - G2's own thresholds
#        (>=25% ETF / >=50% single above the trailing 54d low, past
#        prices only; no new constant). Walk-forward: capture 16 -> 26
#        of 122, AP 0.286 -> 0.435, capture-gain CI [+3.5pp, +13pp].
#      * the trigger runs on the 7d-SMOOTHED score (ROLL - the house
#        one-week window; NB06 blip study): AP 0.435 -> 0.449, FA
#        41 -> 39, at a recorded cost of 2 captures (26 -> 24). One loud
#        afternoon can no longer fire a one-day episode.
#
#    GET IN (euphoria starting) = the tournament-winning onset rules
#    with PHASE-AWARE candidacy + the same 7d smoothing: a day that
#    already satisfies every END gate (A1 crowd swollen AND A2 attention
#    >= its 90th pct AND A3's persistence e2 > 0 - the detector's OWN
#    existing gates, no new constant) is END-STAGE, and declaring a
#    START there is definitionally incoherent. Measured (NB06):
#    START-within-21d-of-END adjacency 20 -> 2, LATE starts 21 -> 10,
#    FA 169 -> 124, at a recorded cost of captures 29 -> 20 of 125.
#    DESK DECISION: the desk stated three times that a START landing on
#    top of an END is the error that destroys PM trust; the adjacency
#    priority overrules the raw-capture utility rule, and the cost is
#    recorded here and in NB06, not hidden.
# ---------------------------------------------------------------------------
from src.config import (ROLL, EUPHORIA_ATT_GATE,  # noqa: E402
                        EUPHORIA_BOOM_MIN_ETF, EUPHORIA_BOOM_MIN_SINGLE,
                        EUPHORIA_BOOM_WINDOW_D, EUPHORIA_BOOM_WINDOW_MIN_D,
                        EUPHORIA_ONSET_HYPE_MIN)


def boom_state_frame(series: list, pxmap: dict) -> pd.DataFrame:
    """name/date/boom_state: is the price >= its G2 boom threshold above
    its own trailing EUPHORIA_BOOM_WINDOW_D low? Trailing only (day t uses
    closes <= t); the SIZE thresholds are the ground-truth constants,
    reused, so the gate introduces no new size number.

    THE WINDOW IS NOT THE GROUND TRUTH'S WINDOW (desk decision 2026-07-29).
    `find_episodes` above walks back 120 days because that is the yardstick
    an episode is DEFINED by; this gate walks back
    EUPHORIA_BOOM_WINDOW_D (54) because that is a prediction-time choice
    and 120 was letting crash-rebounds through - `semiconductors` fired
    GET OUT twice in early 2023 while 20-25% below its own Dec-2021 peak,
    on a bounce off the Oct-2022 bottom. The window was swept on the NB07
    section A3b frontier; the table, the selection rule and the recorded
    cost (the walk-forward loses its 2020 test year) are in src/config.py
    beside the constant. Deliberately two windows, deliberately not
    shared."""
    rows = []
    for es in series:
        px = pxmap[es.symbol].dropna().asfreq("D").ffill()
        low_w = px.rolling(EUPHORIA_BOOM_WINDOW_D,
                           min_periods=EUPHORIA_BOOM_WINDOW_MIN_D).min()
        bm = (EUPHORIA_BOOM_MIN_SINGLE if es.kind == "single"
              else EUPHORIA_BOOM_MIN_ETF)
        rows.append(pd.DataFrame({"name": es.name, "date": px.index,
                                  "boom_state": ((px / low_w - 1) >= bm)
                                  .values}))
    return pd.concat(rows, ignore_index=True)


def end_stage_mask(df: pd.DataFrame) -> pd.Series:
    """END-STAGE = the day already satisfies every END gate (A1 + A2 +
    A3-persistence). Built ONLY from the detector's own frozen gate
    constants - no new threshold enters the system."""
    return ((df["e1"] >= EUPHORIA_ATT_GATE) & (df["e2"] > 0)
            & df["hype_ok"].astype(bool))


def _smooth_by_name(scores: pd.Series, names: pd.Series,
                    dates: pd.Series | None = None) -> pd.Series:
    """The desk trigger smoothing: a trailing ROLL-day (7d - the house
    one-week window, same as A1's mention-share window) mean over each
    instrument's own candidate days. Trailing => no look-ahead.

    CALENDAR-AWARE SINCE 2026-07-31, and this is a DEFECT FIX, not a
    tuning choice.  The old code rolled over each name's candidate-ROW
    sequence (`rolling(ROLL)` = last 7 rows), so a multi-year candidacy
    gap was silently bridged: the 2026-07-06 `biotech_pharma` GET OUT
    fired at 0.658 (106% of trigger) whose 7-row window contained SIX
    candidate days from May/Dec 2020 and one gate-zeroed day from 2026 -
    the flag fired on evidence from a mania five and a half years
    earlier (traced row-by-row from the stores; the desk caught it from
    the hover: "why does this activate get out?").  With `dates`, the
    window is the last ROLL CALENDAR days, closed on the right, so
    evidence older than one week can never reach a trigger.  On a dense
    daily candidate run the two windows contain identical rows, so
    ordinary in-episode behaviour is unchanged; only gap-bridging dies.
    Thresholds were re-frozen through the standard walk-forward after
    this change (see euphoria_desk_report.json / notebook 04 SS1.1).
    Without `dates` the row-based behaviour is kept (unit contract)."""
    if dates is None:
        return scores.groupby(names.values).transform(
            lambda g: g.rolling(ROLL, min_periods=1).mean())
    frame = pd.DataFrame({"s": scores.values,
                          "d": pd.to_datetime(pd.Series(dates).values),
                          "n": pd.Series(names).values},
                         index=scores.index)
    out = pd.Series(index=scores.index, dtype="float64")
    for _, g in frame.groupby("n", sort=False):
        g2 = g.sort_values("d")
        s = pd.Series(g2["s"].values, index=pd.DatetimeIndex(g2["d"]))
        sm = s.rolling(f"{ROLL}D", min_periods=1).mean()
        out.loc[g2.index] = sm.values
    return out


def desk_end_fit(train, apply, feats):
    """The GET OUT score (rules family - fitting is a no-op): mean of
    the incumbent bank, zeroed where the A2/A3 gates fail (gates in
    score space, so one threshold governs), then 7-calendar-day
    smoothed."""
    sc = apply[feats].mean(axis=1)
    sc = sc.where((apply["e1"] >= EUPHORIA_ATT_GATE) & (apply["e2"] > 0),
                  0.0)
    return _smooth_by_name(sc, apply["name"], apply["date"]).values


def desk_onset_fit(train, apply, feats):
    """The GET IN score: the tournament-winning onset rules (mean of the
    locked bank), 7-calendar-day smoothed. Phase-awareness lives in
    CANDIDACY (the frame passed in), not in the score."""
    return _smooth_by_name(apply[feats].mean(axis=1),
                           apply["name"], apply["date"]).values


def desk_candidacy(frame_px: pd.DataFrame) -> tuple:
    """The two desk candidate frames from a day frame already merged
    with boom_state. Returns (end_frame, onset_frame).

    THE ONSET FLOOR IS EUPHORIA_ONSET_HYPE_MIN (1.10), NOT 1.0, since
    2026-07-29 - at 1.0 this rule breached its own false-alarm budget
    (0.255 vs 0.23) from the day it shipped. The sweep, the cost (one
    capture) and what it buys (budget compliance, late starts 6 -> 2) are
    in src/config.py beside the constant. The CROWD-ONLY onset store above
    still uses 1.0 on purpose: different detector, different record, not
    swept here."""
    end_f = frame_px[frame_px["hype_ok"].astype(bool)
                     & frame_px["boom_state"].astype(bool)].copy()
    onset_f = frame_px[(frame_px["hype_raw"] >= EUPHORIA_ONSET_HYPE_MIN)
                       & ~end_stage_mask(frame_px)].copy()
    return end_f, onset_f


def _desk_test_years(stored: dict | None) -> list:
    """Every walk-forward test year the stored desk record covers, across
    both rules. Shared by the bootstrap test and the staleness notice so
    the two can never disagree about what the record contains."""
    if not stored or "get_in" not in stored or "get_out" not in stored:
        return []
    years = []
    for k in ("get_in", "get_out"):
        years += stored[k].get("walk_forward", {}).get("test_years") or []
    return years


def desk_needs_research(stored: dict | None, data_max_year: int) -> bool:
    """Same convention as onset_needs_research, changed on the same date
    (2026-07-28) for the same reasons: research only to BOOTSTRAP a
    machine with no usable frozen record. A record that lags the data is
    a notice, not a refit - see `desk_record_lags_data`."""
    return not _desk_test_years(stored)


def desk_record_lags_data(stored: dict | None, data_max_year: int):
    """Newest desk walk-forward test year when it lags the data, else
    None."""
    years = _desk_test_years(stored)
    if not years:
        return None
    newest = max(int(y) for y in years)
    return newest if data_max_year > newest else None


# ---------------------------------------------------------------------------
# 7. EPISODE COHERENCE - the desk-facing state machine (2026-07-24)
# ---------------------------------------------------------------------------
def episode_coherent_alerts(onset_dates, top_dates,
                            cooldown: int = EUPHORIA_COOLDOWN_DAYS):
    """The desk-facing state machine, ASYMMETRIC by evidence
    (2026-07-24): a new START within `cooldown` days AFTER an END is a
    contradictory flip and is SUPPRESSED (you cannot start euphoria the
    desk was just told is ending); a fast START -> END is a REAL,
    violent mania and the ENDING (risk) signal is NEVER suppressed.

    The asymmetry was measured, not assumed: the symmetric rule cost the
    top detector half its walk-forward captures (17 -> 9) for only 8
    fewer false alarms - fast episodes legitimately run start-to-end
    inside one cooldown - while the onset direction cost 2 captures and
    removed 7 FAs. The cooldown (21d) is the project's existing
    one-episode timescale; no new constant. Same-day tie: the END wins
    and the same-day START is suppressed.

    Returns (kept_onset_dates, kept_top_dates), chronological."""
    tops = sorted(pd.Timestamp(d) for d in top_dates)
    kept_onset = []
    for d in sorted(pd.Timestamp(x) for x in onset_dates):
        blocked = any(0 <= (d - t).days < cooldown for t in tops)
        if not blocked:
            kept_onset.append(d)
    return kept_onset, tops
